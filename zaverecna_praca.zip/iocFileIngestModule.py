import jarray
import inspect
from java.lang import System
from java.util.logging import Level
from org.sleuthkit.datamodel import Score
from org.sleuthkit.datamodel import SleuthkitCase
from org.sleuthkit.datamodel import AbstractFile
from org.sleuthkit.datamodel import ReadContentInputStream
from org.sleuthkit.datamodel import BlackboardArtifact
from org.sleuthkit.datamodel import BlackboardAttribute
from org.sleuthkit.datamodel import TskData
from org.sleuthkit.autopsy.ingest import IngestModule
from org.sleuthkit.autopsy.ingest.IngestModule import IngestModuleException
from org.sleuthkit.autopsy.ingest import DataSourceIngestModule
from org.sleuthkit.autopsy.ingest import FileIngestModule
from org.sleuthkit.autopsy.ingest import IngestModuleFactoryAdapter
from org.sleuthkit.autopsy.ingest import IngestMessage
from org.sleuthkit.autopsy.ingest import IngestServices
from org.sleuthkit.autopsy.ingest import ModuleDataEvent
from org.sleuthkit.autopsy.coreutils import Logger
from org.sleuthkit.autopsy.casemodule import Case
from org.sleuthkit.autopsy.casemodule.services import Services
from org.sleuthkit.autopsy.casemodule.services import FileManager
from org.sleuthkit.autopsy.casemodule.services import Blackboard
from java.util import Arrays

import re

class IocFileIngestModuleFactory(IngestModuleFactoryAdapter):

    moduleName = "Finder of Web Indicators of Compromise"

    def getModuleDisplayName(self):
        return self.moduleName

    def getModuleDescription(self):
        return "Module that find basic WIoCs"

    def getModuleVersionNumber(self):
        return "1.0"

    # Return true if module wants to get called for each file
    def isFileIngestModuleFactory(self):
        return True

    # can return null if isFileIngestModuleFactory returns false
    def createFileIngestModule(self, ingestOptions):
        return IoCFileIngestModule()


# File-level ingest module.  One gets created per thread.
# Looks at the attributes of the passed in file.
class IoCFileIngestModule(FileIngestModule):

    _logger = Logger.getLogger(IocFileIngestModuleFactory.moduleName)

    def log(self, level, msg):
        self._logger.logp(level, self.__class__.__name__, inspect.stack()[1][3], msg)

    def __init__(self):
        self.context = None

    # Where any setup and configuration is done
    # 'context' is an instance of org.sleuthkit.autopsy.ingest.IngestJobContext.
    def startUp(self, context):
        self.context = context
        self.filesFound = 0

        # Throw an IngestModule.IngestModuleException exception if there was a problem setting up
        # raise IngestModuleException("Oh No!")
        pass

    def createKeywordHitArtifact(self, blackboard, file, keyword, name, regex, preview, rowNum):
        attributes = Arrays.asList(
            BlackboardAttribute(BlackboardAttribute.Type.TSK_KEYWORD, IocFileIngestModuleFactory.moduleName, keyword),
            BlackboardAttribute(BlackboardAttribute.Type.TSK_SET_NAME, IocFileIngestModuleFactory.moduleName, name),
            BlackboardAttribute(BlackboardAttribute.Type.TSK_KEYWORD_REGEXP, IocFileIngestModuleFactory.moduleName, regex),
            BlackboardAttribute(BlackboardAttribute.Type.TSK_KEYWORD_PREVIEW, IocFileIngestModuleFactory.moduleName, preview)
        )
        
        art = file.newAnalysisResult(
            BlackboardArtifact.Type.TSK_KEYWORD_HIT,
            Score.SCORE_LIKELY_NOTABLE,
            "Occurrence on line: " + str(rowNum),
            name,
            None,
            attributes).getAnalysisResult()
        try:
            blackboard.postArtifact(art, IocFileIngestModuleFactory.moduleName)
        except Blackboard.BlackboardException as e:
            self.log(Level.SEVERE, "Error indexing artifact " + art.getDisplayName())

        return

    # Where the analysis is done.  Each file will be passed into here.
    # The 'file' object being passed in is of type org.sleuthkit.datamodel.AbstractFile.
    def process(self, file):
        # Skip non-files
        if ((file.getType() == TskData.TSK_DB_FILES_TYPE_ENUM.UNALLOC_BLOCKS) or
            (file.getType() == TskData.TSK_DB_FILES_TYPE_ENUM.UNUSED_BLOCKS) or
            (file.isFile() == False)):
            return IngestModule.ProcessResult.OK

        # Use blackboard class to index blackboard artifacts for keyword search
        blackboard = Case.getCurrentCase().getSleuthkitCase().getBlackboard()

        hasLogExt = re.search("(\.log.{0,1}\d{0,1})$", file.getName())    
        if hasLogExt:
            # 
            # Mark log files as interesting
            # 
            attributes = Arrays.asList(
                BlackboardAttribute(BlackboardAttribute.Type.TSK_SET_NAME, IocFileIngestModuleFactory.moduleName, "Log Files")
            )

            art = file.newAnalysisResult(
                BlackboardArtifact.Type.TSK_INTERESTING_FILE_HIT,
                Score.SCORE_LIKELY_NOTABLE,
                None,
                "Log Files",
                None,
                attributes).getAnalysisResult()
            try:
                blackboard.postArtifact(art, IocFileIngestModuleFactory.moduleName)
            except Blackboard.BlackboardException as e:
                self.log(Level.SEVERE, "Error indexing artifact " + art.getDisplayName())

        if (file.getName().lower().endswith("wp-config.php")):
            # 
            # Mark WP config files as interesting
            # 
            attributes = Arrays.asList(
                BlackboardAttribute(BlackboardAttribute.Type.TSK_SET_NAME, IocFileIngestModuleFactory.moduleName, "WP Config Files")
            )

            art = file.newAnalysisResult(
                BlackboardArtifact.Type.TSK_INTERESTING_FILE_HIT,
                Score.SCORE_LIKELY_NOTABLE,
                None,
                "WP Config Files",
                None,
                attributes).getAnalysisResult()
            try:
                blackboard.postArtifact(art, IocFileIngestModuleFactory.moduleName)
            except Blackboard.BlackboardException as e:
                self.log(Level.SEVERE, "Error indexing artifact " + art.getDisplayName())

        if (hasLogExt):  
            # detect exploited type SQL Injection
            regex1 = r"(?i)(\%20| )union(\%20| )select(\%20| )[a-zA-Z0-9,._]*(\%20| )from(\%20| )[a-zA-Z0-9,._]*"
            # detect typical SQL Injection
            regex2 = "(?i)\w*((\%27)|(\'))\s*((\%6F)|o|(\%4F))((\%72)|r|(\%52))"
            # detect UNION and other keywords
            regex3 = r"(?i)(ALTER|CREATE|DELETE|DROP|EXEC(UTE){0,1}|INSERT( +INTO){0,1}|MERGE|SELECT|UPDATE|UNION( +ALL){0,1})\b"
            # detect CURL and other shell keywords
            regex4 = r"(?i)(curl|scp|sftp|tftp|rsync|finger|wget)\b"

            # detect <img src XSS atack
            regex6 = "(?i)((\%3C)|<)((\%69)|i|(\%49))((\%6D)|m|(\%4D))((\%67)|g|(\%47))[^\n]+((\%3E)|>)"
            # detect HTML tags based XSS
            regex7 = r"(?i)(javascript|vbscript|expression|applet|script|embed|object|iframe|frame|frameset|alert)\b"

            # detect directory traversal attack
            regex8 = "(\.|(%|%25)2E)(\.|(%|%25)2E)(\/|(%|%25)2F|\\|(%|%25)5C)"
            rowNum = 1

            self.log(Level.INFO, "NAZOV SUBORU: " + file.getName())

            rawFile = ReadContentInputStream(file)
            fileBuffer = jarray.zeros(file.getSize(), "b")
            fileBytes = rawFile.read(fileBuffer)

            fileContent = ""
            for byte in fileBuffer:
                fileContent += unichr(byte)
            fileContent = fileContent.replace('\x00', '')

            for line in fileContent.split('\n'):
                match1 = re.search(regex1, line)
                match2 = re.search(regex2, line)
                match3 = re.search(regex3, line)
                match4 = re.search(regex4, line)
                match6 = re.search(regex6, line)
                match7 = re.search(regex7, line)
                match8 = re.search(regex8, line)

                # next 3 ifs are for SQL Injection detection
                if match1:
                    matchString = match1.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString, "SQL Injection", regex1, line, rowNum)

                if match2:
                    matchString2 = match2.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString2, "SQL Injection", regex2, line, rowNum)

                if match3:
                    matchString3 = match3.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString3, "SQL Injection", regex3, line, rowNum)

                if match4:
                    matchString4 = match4.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString4, "Shell Commands", regex4, line, rowNum)

                if match6:
                    matchString6 = match6.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString6, "Cross-Site Scripting", regex6, line, rowNum)

                if match7:
                    matchString7 = match7.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString7, "Cross-Site Scripting", regex7, line, rowNum)

                if match8:
                    matchString8 = match8.group()
                    self.createKeywordHitArtifact(blackboard, file, matchString8, "Directory Traversal Attack", regex8, line, rowNum)
                
                if "/etc/passwd" in line:
                    self.createKeywordHitArtifact(blackboard, file, "/etc/passwd", "Directory Traversal Attack", "/etc/passwd", line, rowNum)
                
                if "/var/" in line:
                    self.createKeywordHitArtifact(blackboard, file, "/var/", "Directory Traversal Attack", "/var/", line, rowNum)

                rowNum += 1

            self.log(Level.INFO, "Found a text file: " + file.getName())
            self.filesFound+=1

        return IngestModule.ProcessResult.OK

    # Where any shutdown code is run and resources are freed.
    def shutDown(self):
        message = IngestMessage.createMessage(
            IngestMessage.MessageType.DATA, 
            IocFileIngestModuleFactory.moduleName,
            str(self.filesFound) + " files found")
        ingestServices = IngestServices.getInstance().postMessage(message)